﻿using System;
using System.Data;
using System.Windows.Forms;

public partial class Form1 : Form
{
    DataTable dt = new DataTable();

    public Form1()
    {
        InitializeComponent(); // Initialize all UI components
        CreateNewRow(); // Initialize columns when the form loads
    }

    public void CreateNewRow()
    {
        if (dt.Columns.Count == 0) // Create columns only once
        {
            dt.Columns.Add(new DataColumn("EMPLOYEE ID", typeof(int)));
            dt.Columns.Add(new DataColumn("FULL NAME", typeof(string)));
            dt.Columns.Add(new DataColumn("BOOKING DATE", typeof(string)));
            dt.Columns.Add(new DataColumn("AMOUNT", typeof(string)));
            dt.Columns.Add(new DataColumn("CATEGORY", typeof(string)));
        }
    }

    public void AddRowToDataTable()
    {
        // Add a new row with user inputs
        dt.Rows.Add(
            Convert.ToInt32(txt_employeeId.Text),
            txt_fullName.Text,
            txt_bookingDate.Text,
            txt_amount.Text,
            txt_category.Text
        );
        dataGridView1.DataSource = dt; // Update DataGridView with the new data
    }

    private void btn_submit_Click(object sender, EventArgs e)
    {
        AddRowToDataTable(); // Call the method to add a new row when the button is clicked
    }
}
