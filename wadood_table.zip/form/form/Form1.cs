partial class Form1
{
    private System.Windows.Forms.TextBox txt_employeeId;  // Changed variable name
    private System.Windows.Forms.TextBox txt_fullName;    // Changed variable name
    private System.Windows.Forms.TextBox txt_bookingDate; // Changed variable name
    private System.Windows.Forms.TextBox txt_amount;      // Changed variable name
    private System.Windows.Forms.TextBox txt_category;    // Changed variable name
    private System.Windows.Forms.Button btn_submit;       // Changed variable name
    private System.Windows.Forms.DataGridView dataGridView1;

    private System.Windows.Forms.Label lbl_employeeId;    // Changed variable name
    private System.Windows.Forms.Label lbl_fullName;      // Changed variable name
    private System.Windows.Forms.Label lbl_bookingDate;   // Changed variable name
    private System.Windows.Forms.Label lbl_amount;        // Changed variable name
    private System.Windows.Forms.Label lbl_category;      // Changed variable name

    private void InitializeComponent()
    {
        this.txt_employeeId = new System.Windows.Forms.TextBox();
        this.txt_fullName = new System.Windows.Forms.TextBox();
        this.txt_bookingDate = new System.Windows.Forms.TextBox();
        this.txt_amount = new System.Windows.Forms.TextBox();
        this.txt_category = new System.Windows.Forms.TextBox();
        this.btn_submit = new System.Windows.Forms.Button();
        this.dataGridView1 = new System.Windows.Forms.DataGridView();

        this.lbl_employeeId = new System.Windows.Forms.Label();
        this.lbl_fullName = new System.Windows.Forms.Label();
        this.lbl_bookingDate = new System.Windows.Forms.Label();
        this.lbl_amount = new System.Windows.Forms.Label();
        this.lbl_category = new System.Windows.Forms.Label();

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
        this.SuspendLayout();

        // txt_employeeId
        this.txt_employeeId.Location = new System.Drawing.Point(160, 20);  // Changed location x from 150 to 160
        this.txt_employeeId.Name = "txt_employeeId";
        this.txt_employeeId.Size = new System.Drawing.Size(120, 20);  // Changed size from 100 to 120
        this.txt_employeeId.TabIndex = 0;

        // lbl_employeeId
        this.lbl_employeeId.AutoSize = true;
        this.lbl_employeeId.Location = new System.Drawing.Point(20, 20);
        this.lbl_employeeId.Name = "lbl_employeeId";
        this.lbl_employeeId.Size = new System.Drawing.Size(68, 13);  // Changed text value
        this.lbl_employeeId.TabIndex = 7;
        this.lbl_employeeId.Text = "Employee ID:";

        // txt_fullName
        this.txt_fullName.Location = new System.Drawing.Point(160, 50);
        this.txt_fullName.Name = "txt_fullName";
        this.txt_fullName.Size = new System.Drawing.Size(120, 20);
        this.txt_fullName.TabIndex = 1;

        // lbl_fullName
        this.lbl_fullName.AutoSize = true;
        this.lbl_fullName.Location = new System.Drawing.Point(20, 50);
        this.lbl_fullName.Name = "lbl_fullName";
        this.lbl_fullName.Size = new System.Drawing.Size(57, 13);  // Changed text value
        this.lbl_fullName.TabIndex = 8;
        this.lbl_fullName.Text = "Full Name:";

        // txt_bookingDate
        this.txt_bookingDate.Location = new System.Drawing.Point(160, 80);
        this.txt_bookingDate.Name = "txt_bookingDate";
        this.txt_bookingDate.Size = new System.Drawing.Size(120, 20);
        this.txt_bookingDate.TabIndex = 2;

        // lbl_bookingDate
        this.lbl_bookingDate.AutoSize = true;
        this.lbl_bookingDate.Location = new System.Drawing.Point(20, 80);
        this.lbl_bookingDate.Name = "lbl_bookingDate";
        this.lbl_bookingDate.Size = new System.Drawing.Size(74, 13);  // Changed text value
        this.lbl_bookingDate.TabIndex = 9;
        this.lbl_bookingDate.Text = "Booking Date:";

        // txt_amount
        this.txt_amount.Location = new System.Drawing.Point(160, 110);
        this.txt_amount.Name = "txt_amount";
        this.txt_amount.Size = new System.Drawing.Size(120, 20);
        this.txt_amount.TabIndex = 3;

        // lbl_amount
        this.lbl_amount.AutoSize = true;
        this.lbl_amount.Location = new System.Drawing.Point(20, 110);
        this.lbl_amount.Name = "lbl_amount";
        this.lbl_amount.Size = new System.Drawing.Size(46, 13);  // Changed text value
        this.lbl_amount.TabIndex = 10;
        this.lbl_amount.Text = "Amount:";

        // txt_category
        this.txt_category.Location = new System.Drawing.Point(160, 140);
        this.txt_category.Name = "txt_category";
        this.txt_category.Size = new System.Drawing.Size(120, 20);
        this.txt_category.TabIndex = 4;

        // lbl_category
        this.lbl_category.AutoSize = true;
        this.lbl_category.Location = new System.Drawing.Point(20, 140);
        this.lbl_category.Name = "lbl_category";
        this.lbl_category.Size = new System.Drawing.Size(52, 13);  // Changed text value
        this.lbl_category.TabIndex = 11;
        this.lbl_category.Text = "Category:";

        // btn_submit
        this.btn_submit.Location = new System.Drawing.Point(160, 170);  // Changed name and size from 100 to 120
        this.btn_submit.Name = "btn_submit";
        this.btn_submit.Size = new System.Drawing.Size(120, 30);
        this.btn_submit.TabIndex = 5;
        this.btn_submit.Text = "Submit";  // Changed text value
        this.btn_submit.UseVisualStyleBackColor = true;
        this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);

        // dataGridView1
        this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridView1.Location = new System.Drawing.Point(300, 20);
        this.dataGridView1.Name = "dataGridView1";
        this.dataGridView1.Size = new System.Drawing.Size(400, 180);
        this.dataGridView1.TabIndex = 6;

        // Form1
        this.ClientSize = new System.Drawing.Size(800, 250);
        this.Controls.Add(this.lbl_employeeId);
        this.Controls.Add(this.lbl_fullName);
        this.Controls.Add(this.lbl_bookingDate);
        this.Controls.Add(this.lbl_amount);
        this.Controls.Add(this.lbl_category);
        this.Controls.Add(this.txt_employeeId);
        this.Controls.Add(this.txt_fullName);
        this.Controls.Add(this.txt_bookingDate);
        this.Controls.Add(this.txt_amount);
        this.Controls.Add(this.txt_category);
        this.Controls.Add(this.btn_submit);
        this.Controls.Add(this.dataGridView1);
        this.Name = "Form1";
        this.Text = "Reservation Form";  // Changed text value

        ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
    }
}
